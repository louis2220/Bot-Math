# 🤖 Discord Bot — Guia Completo

Bot completo para Discord com moderação, tickets, tags, clopen, modmail, automod e muito mais.

---

## 📁 Estrutura do Projeto

```
discord-bot/
├── main.py                 # Entrada principal do bot
├── Procfile                # Deploy no Railway
├── railway.json            # Configuração Railway
├── requirements.txt        # Dependências Python
├── .env.example            # Variáveis de ambiente (exemplo)
├── .gitignore
├── utils/
│   ├── config.py           # Lê variáveis de ambiente
│   ├── db.py               # Conexão e tabelas PostgreSQL
│   └── helpers.py          # Utilitários (embeds, duração, etc)
└── cogs/
    ├── admin.py            # Gerenciamento do bot (owner)
    ├── moderation.py       # Ban, kick, mute, warn, purge
    ├── tickets.py          # Visualizar e gerenciar tickets
    ├── tags.py             # Sistema de tags/factoids
    ├── roles.py            # Self-roles e role reactions
    ├── clopen.py           # Canais de ajuda open/close
    ├── modmail.py          # DMs → canal staff
    ├── automod.py          # Anti-spam, anti-phishing
    ├── reminders.py        # Lembretes com timer
    ├── logs.py             # Log de mensagens e membros
    └── help.py             # Comando de ajuda
```

---

## 🚀 Deploy no Railway (passo a passo)

### 1. Criar o bot no Discord

1. Acesse [discord.com/developers/applications](https://discord.com/developers/applications)
2. Clique em **New Application** → dê um nome
3. Vá em **Bot** → clique em **Add Bot**
4. Em **Privileged Gateway Intents**, ative:
   - ✅ `PRESENCE INTENT`
   - ✅ `SERVER MEMBERS INTENT`
   - ✅ `MESSAGE CONTENT INTENT`
5. Clique em **Reset Token** e copie o token — você vai precisar dele
6. Vá em **OAuth2 → URL Generator**:
   - Scopes: `bot` + `applications.commands`
   - Permissions: `Administrator` (ou personalize)
   - Copie o link e use para adicionar o bot ao seu servidor

---

### 2. Subir o código no GitHub

1. Crie um repositório no GitHub
2. Faça o push do projeto:

```bash
git init
git add .
git commit -m "Initial bot setup"
git remote add origin https://github.com/seu-usuario/seu-repo.git
git push -u origin main
```

---

### 3. Criar projeto no Railway

1. Acesse [railway.app](https://railway.app) e faça login
2. Clique em **New Project → Deploy from GitHub repo**
3. Selecione seu repositório
4. O Railway vai detectar o projeto automaticamente

---

### 4. Adicionar PostgreSQL no Railway

1. No seu projeto Railway, clique em **+ New**
2. Selecione **Database → Add PostgreSQL**
3. O Railway cria o banco automaticamente
4. Clique no serviço PostgreSQL → aba **Variables**
5. Copie o valor da variável `DATABASE_URL`

---

### 5. Configurar variáveis de ambiente

No Railway, vá no serviço do **bot** (não no PostgreSQL) → **Variables** → adicione:

| Variável | Valor |
|----------|-------|
| `DISCORD_TOKEN` | Token do seu bot |
| `DATABASE_URL` | URL copiada do PostgreSQL (Railway preenche automático se usar `${{Postgres.DATABASE_URL}}`) |
| `BOT_PREFIX` | `.` (ou o prefixo que quiser) |
| `MOD_LOG_CHANNEL` | ID do canal de logs (ou `0` para desativar) |
| `MODMAIL_CHANNEL` | ID do canal de modmail (ou `0`) |
| `TICKET_LIST_CHANNEL` | ID do canal de tickets (ou `0`) |

> 💡 **Dica Railway:** Em vez de copiar a URL manualmente, use a referência:
> `DATABASE_URL` = `${{Postgres.DATABASE_URL}}`
> Assim o Railway conecta os dois serviços automaticamente.

---

### 6. Deploy!

1. Railway faz deploy automático a cada push no GitHub
2. Acompanhe os logs em **Deployments → View Logs**
3. Se tudo estiver certo, você verá:
   ```
   Connected to PostgreSQL.
   Database tables initialized.
   Loaded cog: cogs.moderation
   ...
   Logged in as SeuBot#1234
   ```

---

## ⚙️ Comandos disponíveis

### Moderação
| Comando | Descrição |
|---------|-----------|
| `.ban @user [motivo]` | Banir usuário |
| `.unban <id> [motivo]` | Desbanir por ID |
| `.kick @user [motivo]` | Expulsar usuário |
| `.mute @user [duração] [motivo]` | Silenciar (timeout) |
| `.unmute @user` | Remover silêncio |
| `.warn @user <motivo>` | Avisar usuário |
| `.history @user` | Ver infrações |
| `.purge <n>` | Deletar mensagens |
| `.note @user <texto>` | Nota de staff |

### Tickets
| Comando | Descrição |
|---------|-----------|
| `.ticket show <id>` | Ver ticket |
| `.ticket hide <id>` | Ocultar ticket |
| `.ticket approve <id>` | Aprovar ticket |
| `.ticket reason <id> <motivo>` | Editar motivo |
| `.tickets @user` | Listar tickets do usuário |

### Tags
| Comando | Descrição |
|---------|-----------|
| `.tag <nome>` | Buscar tag |
| `.tag add <nome> <conteúdo>` | Criar tag |
| `.tag edit <nome> <conteúdo>` | Editar tag |
| `.tag delete <nome>` | Deletar tag |
| `.tag alias <nome> <alias>` | Criar alias |
| `.tag info <nome>` | Info da tag |
| `.tag list` | Listar tags |
| `.tag top` | Tags mais usadas |

### Self Roles
| Comando | Descrição |
|---------|-----------|
| `.selfrole` | Ver cargos disponíveis |
| `.selfrole add @role` | Registrar cargo |
| `.selfrole remove @role` | Remover cargo |
| `/role @role` | Atribuir/remover cargo (slash) |

### Role Reactions
| Comando | Descrição |
|---------|-----------|
| `.rolereact add <msg_id> <emoji> @role` | Vincular reação a cargo |
| `.rolereact remove <msg_id> <emoji>` | Remover vínculo |
| `.rolereact list` | Listar vínculos |

### Clopen (Canais de Ajuda)
| Comando | Descrição |
|---------|-----------|
| `.clopen_register [#canal]` | Registrar canal no sistema |
| `.clopen_list` | Listar canais |
| `.close` | Fechar canal de ajuda |
| `.reopen` | Reabrir canal de ajuda |

### Modmail
| Comando | Descrição |
|---------|-----------|
| `.reply <user_id> <mensagem>` | Responder usuário |
| `.closemail <user_id>` | Fechar thread |
| `.mailthreads` | Listar threads abertas |

### AutoMod
| Comando | Descrição |
|---------|-----------|
| `.automod list` | Listar padrões |
| `.automod add <tipo> <ação> <padrão>` | Adicionar padrão |
| `.automod remove <id>` | Remover padrão |

### Lembretes
| Comando | Descrição |
|---------|-----------|
| `.remindme <duração> <texto>` | Criar lembrete |
| `.reminders` | Listar seus lembretes |
| `.reminders remove <id>` | Deletar lembrete |

### Admin (owner only)
| Comando | Descrição |
|---------|-----------|
| `.cog load <nome>` | Carregar cog |
| `.cog unload <nome>` | Descarregar cog |
| `.cog reload <nome>` | Recarregar cog |
| `.eval <código>` | Executar Python |
| `.sync` | Sincronizar slash commands |

---

## 🛠️ Desenvolvimento local

```bash
# Instalar dependências
pip install -r requirements.txt

# Copiar e preencher .env
cp .env.example .env
# Edite o .env com seu token e DATABASE_URL local

# Rodar
python main.py
```

---

## 📌 Como pegar IDs de canais no Discord

1. Ative o **Modo Desenvolvedor**: Configurações → Avançado → Modo Desenvolvedor
2. Clique com botão direito em qualquer canal → **Copiar ID**
3. Cole o ID na variável correspondente no Railway
