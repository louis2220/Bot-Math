import discord
from discord.ext import commands
from discord import app_commands

from utils.helpers import success_embed, error_embed, info_embed


class Roles(commands.Cog):
    """Self-assign roles and role reactions."""

    def __init__(self, bot):
        self.bot = bot

    # ── Self-assign roles ──────────────────────────────────────────────────

    @commands.group(name="selfrole", aliases=["sr"], invoke_without_command=True)
    async def selfrole(self, ctx):
        """List available self-assign roles."""
        rows = await self.bot.db.fetch(
            "SELECT role_id, label FROM selfroles WHERE guild_id=$1 ORDER BY label",
            ctx.guild.id
        )
        if not rows:
            return await ctx.send(embed=info_embed("Nenhum cargo disponível para auto-atribuição.", "Self Roles"))

        lines = []
        for r in rows:
            role = ctx.guild.get_role(r["role_id"])
            if role:
                label = r["label"] or role.name
                lines.append(f"• {role.mention} — `{label}`")
        await ctx.send(embed=discord.Embed(
            title="Cargos disponíveis",
            description="\n".join(lines),
            color=0x7289DA
        ))

    @selfrole.command(name="add")
    @commands.has_permissions(manage_roles=True)
    async def selfrole_add(self, ctx, role: discord.Role, *, label: str = None):
        """Register a role for self-assignment."""
        try:
            await self.bot.db.execute(
                "INSERT INTO selfroles (guild_id, role_id, label) VALUES ($1,$2,$3)",
                ctx.guild.id, role.id, label or role.name
            )
            await ctx.send(embed=success_embed(f"{role.mention} adicionado como self-role."))
        except Exception:
            await ctx.send(embed=error_embed("Esse cargo já está registrado."))

    @selfrole.command(name="remove")
    @commands.has_permissions(manage_roles=True)
    async def selfrole_remove(self, ctx, role: discord.Role):
        """Remove a role from self-assignment."""
        await self.bot.db.execute(
            "DELETE FROM selfroles WHERE guild_id=$1 AND role_id=$2",
            ctx.guild.id, role.id
        )
        await ctx.send(embed=success_embed(f"{role.mention} removido dos self-roles."))

    @app_commands.command(name="role", description="Atribuir ou remover um cargo de auto-atribuição")
    @app_commands.describe(role="Cargo para adicionar/remover")
    async def slash_role(self, interaction: discord.Interaction, role: discord.Role):
        row = await self.bot.db.fetchrow(
            "SELECT id FROM selfroles WHERE guild_id=$1 AND role_id=$2",
            interaction.guild_id, role.id
        )
        if not row:
            return await interaction.response.send_message("Esse cargo não está disponível para auto-atribuição.", ephemeral=True)

        member = interaction.user
        if role in member.roles:
            await member.remove_roles(role)
            await interaction.response.send_message(f"Cargo {role.mention} removido.", ephemeral=True)
        else:
            await member.add_roles(role)
            await interaction.response.send_message(f"Cargo {role.mention} adicionado.", ephemeral=True)

    # ── Role reactions ─────────────────────────────────────────────────────

    @commands.group(name="rolereact", invoke_without_command=True)
    @commands.has_permissions(manage_roles=True)
    async def rolereact(self, ctx):
        await ctx.send_help(ctx.command)

    @rolereact.command(name="add")
    @commands.has_permissions(manage_roles=True)
    async def rolereact_add(self, ctx, message_id: int, emoji: str, role: discord.Role):
        """Link an emoji reaction on a message to a role."""
        try:
            await self.bot.db.execute(
                """INSERT INTO role_reactions (guild_id, channel_id, message_id, emoji, role_id)
                   VALUES ($1,$2,$3,$4,$5)""",
                ctx.guild.id, ctx.channel.id, message_id, emoji, role.id
            )
            msg = await ctx.channel.fetch_message(message_id)
            await msg.add_reaction(emoji)
            await ctx.send(embed=success_embed(f"Reação {emoji} → {role.mention} adicionada."))
        except Exception as e:
            await ctx.send(embed=error_embed(str(e)))

    @rolereact.command(name="remove")
    @commands.has_permissions(manage_roles=True)
    async def rolereact_remove(self, ctx, message_id: int, emoji: str):
        """Remove a role reaction."""
        await self.bot.db.execute(
            "DELETE FROM role_reactions WHERE message_id=$1 AND emoji=$2",
            message_id, emoji
        )
        await ctx.send(embed=success_embed("Reação removida."))

    @rolereact.command(name="list")
    @commands.has_permissions(manage_roles=True)
    async def rolereact_list(self, ctx):
        """List all role reactions in this server."""
        rows = await self.bot.db.fetch(
            "SELECT message_id, emoji, role_id FROM role_reactions WHERE guild_id=$1",
            ctx.guild.id
        )
        if not rows:
            return await ctx.send(embed=info_embed("Nenhuma role-reaction configurada.", "Role Reactions"))
        lines = []
        for r in rows:
            role = ctx.guild.get_role(r["role_id"])
            lines.append(f"{r['emoji']} → {role.mention if role else r['role_id']} (msg: `{r['message_id']}`)")
        await ctx.send(embed=discord.Embed(
            title="Role Reactions",
            description="\n".join(lines),
            color=0x7289DA
        ))

    # ── Events ─────────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_raw_reaction_add(self, payload: discord.RawReactionActionEvent):
        if not payload.guild_id or payload.member.bot:
            return
        row = await self.bot.db.fetchrow(
            "SELECT role_id FROM role_reactions WHERE message_id=$1 AND emoji=$2",
            payload.message_id, str(payload.emoji)
        )
        if row:
            guild = self.bot.get_guild(payload.guild_id)
            role = guild.get_role(row["role_id"])
            if role:
                await payload.member.add_roles(role)

    @commands.Cog.listener()
    async def on_raw_reaction_remove(self, payload: discord.RawReactionActionEvent):
        if not payload.guild_id:
            return
        row = await self.bot.db.fetchrow(
            "SELECT role_id FROM role_reactions WHERE message_id=$1 AND emoji=$2",
            payload.message_id, str(payload.emoji)
        )
        if row:
            guild = self.bot.get_guild(payload.guild_id)
            member = guild.get_member(payload.user_id)
            role = guild.get_role(row["role_id"])
            if member and role:
                await member.remove_roles(role)


async def setup(bot):
    await bot.add_cog(Roles(bot))
