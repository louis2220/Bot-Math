import discord
from discord.ext import commands

from utils.config import Config
from utils.helpers import success_embed, error_embed, info_embed


class Modmail(commands.Cog):
    """Modmail system — DMs forwarded to a staff channel."""

    def __init__(self, bot):
        self.bot = bot

    async def get_or_create_thread(self, user: discord.User, guild: discord.Guild):
        row = await self.bot.db.fetchrow(
            "SELECT * FROM modmail_threads WHERE guild_id=$1 AND user_id=$2 AND open=TRUE",
            guild.id, user.id
        )
        if row:
            return row, False

        new_row = await self.bot.db.fetchrow(
            """INSERT INTO modmail_threads (guild_id, user_id)
               VALUES ($1,$2) RETURNING *""",
            guild.id, user.id
        )
        return new_row, True

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot:
            return
        if message.guild is not None:
            return  # Only handle DMs
        if not Config.MODMAIL_CHANNEL:
            return

        # Find the first shared guild
        guild = None
        for g in self.bot.guilds:
            if g.get_member(message.author.id):
                guild = g
                break

        if not guild:
            return

        thread, is_new = await self.get_or_create_thread(message.author, guild)
        staff_channel = guild.get_channel(Config.MODMAIL_CHANNEL)
        if not staff_channel:
            return

        e = discord.Embed(
            description=message.content or "*[sem texto]*",
            color=0x7289DA
        )
        e.set_author(name=str(message.author), icon_url=message.author.display_avatar.url)
        e.set_footer(text=f"UserID: {message.author.id} | Thread #{thread['id']}")

        if message.attachments:
            e.add_field(name="Anexos", value="\n".join(a.url for a in message.attachments))

        if is_new:
            await staff_channel.send(f"📬 **Nova mensagem de modmail** de {message.author.mention}", embed=e)
        else:
            await staff_channel.send(embed=e)

        await message.add_reaction("📨")

        # Confirm to user
        try:
            await message.author.send(embed=discord.Embed(
                description="✅ Sua mensagem foi enviada para a equipe. Em breve responderemos!",
                color=0x2ECC71
            ))
        except discord.Forbidden:
            pass

    @commands.command(name="reply", aliases=["mr"])
    @commands.has_permissions(kick_members=True)
    async def reply(self, ctx, user_id: int, *, message: str):
        """Reply to a user's modmail."""
        try:
            user = await self.bot.fetch_user(user_id)
        except discord.NotFound:
            return await ctx.send(embed=error_embed("Usuário não encontrado."))

        e = discord.Embed(
            title=f"Resposta do staff — {ctx.guild.name}",
            description=message,
            color=0x2ECC71
        )
        e.set_footer(text="Esta é uma resposta da equipe de moderação.")

        try:
            await user.send(embed=e)
            await ctx.send(embed=success_embed(f"Resposta enviada para {user}."))
        except discord.Forbidden:
            await ctx.send(embed=error_embed("Não foi possível enviar DM para esse usuário."))

    @commands.command(name="closemail")
    @commands.has_permissions(kick_members=True)
    async def closemail(self, ctx, user_id: int):
        """Close a modmail thread."""
        await self.bot.db.execute(
            "UPDATE modmail_threads SET open=FALSE WHERE guild_id=$1 AND user_id=$2 AND open=TRUE",
            ctx.guild.id, user_id
        )
        await ctx.send(embed=success_embed(f"Thread de modmail para `{user_id}` fechada."))

    @commands.command(name="mailthreads")
    @commands.has_permissions(kick_members=True)
    async def mailthreads(self, ctx):
        """List open modmail threads."""
        rows = await self.bot.db.fetch(
            "SELECT user_id, created_at FROM modmail_threads WHERE guild_id=$1 AND open=TRUE ORDER BY created_at DESC",
            ctx.guild.id
        )
        if not rows:
            return await ctx.send(embed=info_embed("Nenhuma thread aberta.", "Modmail"))

        lines = [f"• <@{r['user_id']}> — aberta em {r['created_at'].strftime('%d/%m/%Y %H:%M')}" for r in rows]
        await ctx.send(embed=discord.Embed(
            title=f"Threads Abertas ({len(rows)})",
            description="\n".join(lines),
            color=0x7289DA
        ))


async def setup(bot):
    await bot.add_cog(Modmail(bot))
