import discord
from discord.ext import commands
from discord import app_commands


class Help(commands.Cog):
    """Custom help command."""

    def __init__(self, bot):
        self.bot = bot

    @commands.command(name="help")
    async def help_cmd(self, ctx, *, command_name: str = None):
        """Show help for commands."""
        prefix = ctx.prefix

        if command_name:
            cmd = self.bot.get_command(command_name)
            if not cmd:
                return await ctx.send(embed=discord.Embed(
                    description=f"❌ Comando `{command_name}` não encontrado.",
                    color=0xE74C3C
                ))
            e = discord.Embed(
                title=f"Comando: {prefix}{cmd.qualified_name}",
                description=cmd.help or "Sem descrição.",
                color=0x7289DA
            )
            if cmd.aliases:
                e.add_field(name="Aliases", value=", ".join(f"`{a}`" for a in cmd.aliases))
            usage = cmd.usage or f"{prefix}{cmd.qualified_name} {cmd.signature}"
            e.add_field(name="Uso", value=f"`{usage}`", inline=False)
            return await ctx.send(embed=e)

        # Group by cog
        e = discord.Embed(
            title="📚 Ajuda",
            description=f"Use `{prefix}help <comando>` para mais detalhes.\nSlash commands disponíveis com `/`.",
            color=0x7289DA
        )

        for cog_name, cog in self.bot.cogs.items():
            cmds = [c for c in cog.get_commands() if not c.hidden]
            if not cmds:
                continue
            cmd_list = "  ".join(f"`{c.name}`" for c in cmds)
            e.add_field(name=cog_name, value=cmd_list, inline=False)

        e.set_footer(text=f"Prefix: {prefix}")
        await ctx.send(embed=e)

    @app_commands.command(name="help", description="Ver comandos disponíveis")
    async def slash_help(self, interaction: discord.Interaction):
        prefix = self.bot.command_prefix if isinstance(self.bot.command_prefix, str) else "."
        e = discord.Embed(
            title="📚 Comandos Disponíveis",
            description=f"Use `{prefix}help <comando>` para detalhes de comandos de texto.",
            color=0x7289DA
        )
        for cog_name, cog in self.bot.cogs.items():
            cmds = [c for c in cog.get_commands() if not c.hidden]
            if not cmds:
                continue
            e.add_field(name=cog_name, value="  ".join(f"`{c.name}`" for c in cmds), inline=False)
        await interaction.response.send_message(embed=e, ephemeral=True)


async def setup(bot):
    await bot.add_cog(Help(bot))
