import datetime
import discord
from discord.ext import commands, tasks
from utils.helpers import success_embed, error_embed, info_embed


TIMEOUT_MINUTES = 30  # Default: 30 min without activity to prompt closure


class Clopen(commands.Cog):
    """Open/Closed help channel system."""

    def __init__(self, bot):
        self.bot = bot
        self.check_timeouts.start()

    def cog_unload(self):
        self.check_timeouts.cancel()

    async def get_channel_state(self, channel_id: int):
        return await self.bot.db.fetchrow(
            "SELECT * FROM clopen_channels WHERE channel_id=$1", channel_id
        )

    # ── Commands ───────────────────────────────────────────────────────────

    @commands.command(name="close")
    async def close(self, ctx):
        """Close this help channel."""
        row = await self.get_channel_state(ctx.channel.id)
        if not row:
            return await ctx.send(embed=error_embed("Este canal não faz parte do sistema de ajuda."))
        if row["status"] not in ("occupied", "pending"):
            return await ctx.send(embed=error_embed("Este canal não está ocupado."))

        is_owner = ctx.author.id == row["owner_id"]
        is_mod = ctx.author.guild_permissions.manage_channels

        if not (is_owner or is_mod):
            return await ctx.send(embed=error_embed("Apenas o dono do canal ou moderadores podem fechá-lo."))

        await self.bot.db.execute(
            "UPDATE clopen_channels SET status='available', owner_id=NULL, opened_at=NULL, last_message_at=NULL WHERE channel_id=$1",
            ctx.channel.id
        )
        embed = discord.Embed(
            description="✅ Canal fechado. Disponível para próxima sessão de ajuda!",
            color=0x2ECC71
        )
        await ctx.send(embed=embed)
        await ctx.channel.edit(topic="🟢 Disponível — Pergunte algo para abrir!")

    @commands.command(name="reopen")
    async def reopen(self, ctx):
        """Reopen this help channel."""
        row = await self.get_channel_state(ctx.channel.id)
        if not row or row["status"] not in ("available", "closed"):
            return await ctx.send(embed=error_embed("Este canal não pode ser reaberto agora."))

        await self.bot.db.execute(
            """UPDATE clopen_channels
               SET status='occupied', owner_id=$1, opened_at=NOW(), last_message_at=NOW()
               WHERE channel_id=$2""",
            ctx.author.id, ctx.channel.id
        )
        await ctx.channel.edit(topic=f"🔴 Ocupado por {ctx.author.display_name}")
        await ctx.send(embed=success_embed("Canal reaberto!"))

    @commands.command(name="clopen_register")
    @commands.has_permissions(manage_channels=True)
    async def clopen_register(self, ctx, channel: discord.TextChannel = None):
        """Register a channel in the clopen system."""
        channel = channel or ctx.channel
        try:
            await self.bot.db.execute(
                "INSERT INTO clopen_channels (guild_id, channel_id, status) VALUES ($1,$2,'available')",
                ctx.guild.id, channel.id
            )
            await ctx.send(embed=success_embed(f"{channel.mention} registrado no sistema clopen."))
        except Exception:
            await ctx.send(embed=error_embed("Canal já registrado."))

    @commands.command(name="clopen_list")
    @commands.has_permissions(manage_channels=True)
    async def clopen_list(self, ctx):
        """List all clopen channels."""
        rows = await self.bot.db.fetch(
            "SELECT channel_id, status, owner_id FROM clopen_channels WHERE guild_id=$1",
            ctx.guild.id
        )
        if not rows:
            return await ctx.send(embed=info_embed("Nenhum canal registrado.", "Clopen"))

        statuses = {"available": "🟢", "occupied": "🔴", "pending": "🟡", "closed": "⚫"}
        lines = []
        for r in rows:
            ch = ctx.guild.get_channel(r["channel_id"])
            icon = statuses.get(r["status"], "⚪")
            owner = f" — <@{r['owner_id']}>" if r["owner_id"] else ""
            lines.append(f"{icon} {ch.mention if ch else r['channel_id']} — `{r['status']}`{owner}")

        await ctx.send(embed=discord.Embed(
            title="Canais Clopen",
            description="\n".join(lines),
            color=0x7289DA
        ))

    # ── Events ─────────────────────────────────────────────────────────────

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return

        row = await self.get_channel_state(message.channel.id)
        if not row:
            return

        if row["status"] == "available":
            # Open the channel for this user
            await self.bot.db.execute(
                """UPDATE clopen_channels
                   SET status='occupied', owner_id=$1, opened_at=NOW(), last_message_at=NOW()
                   WHERE channel_id=$2""",
                message.author.id, message.channel.id
            )
            await message.channel.edit(topic=f"🔴 Ocupado por {message.author.display_name}")
            await message.add_reaction("✅")

        elif row["status"] in ("occupied", "pending"):
            # Update last activity
            await self.bot.db.execute(
                "UPDATE clopen_channels SET last_message_at=NOW(), status='occupied' WHERE channel_id=$1",
                message.channel.id
            )

    @tasks.loop(minutes=5)
    async def check_timeouts(self):
        """Check for idle channels and prompt for closure."""
        threshold = datetime.datetime.utcnow() - datetime.timedelta(minutes=TIMEOUT_MINUTES)
        rows = await self.bot.db.fetch(
            """SELECT * FROM clopen_channels
               WHERE status='occupied' AND last_message_at < $1""",
            threshold
        )
        for row in rows:
            channel = self.bot.get_channel(row["channel_id"])
            if not channel:
                continue
            await self.bot.db.execute(
                "UPDATE clopen_channels SET status='pending' WHERE channel_id=$1",
                row["channel_id"]
            )
            owner = channel.guild.get_member(row["owner_id"])
            mention = owner.mention if owner else "Usuário"
            await channel.send(
                f"{mention} Seu pedido de ajuda está inativo há {TIMEOUT_MINUTES} minutos.\n"
                f"Digite `{self.bot.command_prefix}close` para fechar, ou continue a conversa para manter aberto."
            )

    @check_timeouts.before_loop
    async def before_check(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(Clopen(bot))
