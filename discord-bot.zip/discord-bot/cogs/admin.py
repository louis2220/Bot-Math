import io
import textwrap
import traceback
from contextlib import redirect_stdout

import discord
from discord.ext import commands

from utils.helpers import success_embed, error_embed, info_embed


class Admin(commands.Cog):
    """Bot management commands (owner only)."""

    def __init__(self, bot):
        self.bot = bot

    def cog_check(self, ctx):
        return ctx.author.id in self.bot.owner_ids or self.bot.is_owner(ctx.author)

    # ── Plugin management ──────────────────────────────────────────────────

    @commands.group(name="cog", invoke_without_command=True)
    @commands.is_owner()
    async def cog_cmd(self, ctx):
        loaded = list(self.bot.cogs.keys())
        await ctx.send(embed=info_embed(
            "\n".join(f"• `{c}`" for c in loaded),
            title=f"Cogs carregados ({len(loaded)})"
        ))

    @cog_cmd.command(name="load")
    @commands.is_owner()
    async def cog_load(self, ctx, name: str):
        try:
            await self.bot.load_extension(f"cogs.{name}")
            await ctx.send(embed=success_embed(f"`cogs.{name}` carregado."))
        except Exception as e:
            await ctx.send(embed=error_embed(str(e)))

    @cog_cmd.command(name="unload")
    @commands.is_owner()
    async def cog_unload(self, ctx, name: str):
        try:
            await self.bot.unload_extension(f"cogs.{name}")
            await ctx.send(embed=success_embed(f"`cogs.{name}` descarregado."))
        except Exception as e:
            await ctx.send(embed=error_embed(str(e)))

    @cog_cmd.command(name="reload")
    @commands.is_owner()
    async def cog_reload(self, ctx, name: str):
        try:
            await self.bot.reload_extension(f"cogs.{name}")
            await ctx.send(embed=success_embed(f"`cogs.{name}` recarregado."))
        except Exception as e:
            await ctx.send(embed=error_embed(str(e)))

    # ── Eval ──────────────────────────────────────────────────────────────

    @commands.command(name="eval")
    @commands.is_owner()
    async def _eval(self, ctx, *, code: str):
        """Execute arbitrary Python code."""
        # Strip code blocks if present
        if code.startswith("```") and code.endswith("```"):
            code = "\n".join(code.split("\n")[1:-1])

        env = {
            "bot": self.bot,
            "ctx": ctx,
            "guild": ctx.guild,
            "channel": ctx.channel,
            "author": ctx.author,
            "db": self.bot.db,
            "discord": discord,
        }
        env.update(globals())

        stdout = io.StringIO()
        wrapped = f"async def __eval():\n{textwrap.indent(code, '    ')}"

        try:
            exec(wrapped, env)
            with redirect_stdout(stdout):
                result = await env["__eval"]()
        except Exception:
            output = traceback.format_exc()
        else:
            output = stdout.getvalue()
            if result is not None:
                output += str(result)

        output = output or "(sem output)"
        if len(output) > 1990:
            output = output[:1990] + "..."

        await ctx.send(f"```py\n{output}\n```")

    # ── Sync slash commands ────────────────────────────────────────────────

    @commands.command(name="sync")
    @commands.is_owner()
    async def sync(self, ctx):
        """Sync slash commands globally."""
        await self.bot.tree.sync()
        await ctx.send(embed=success_embed("Slash commands sincronizados."))

    @commands.command(name="syncguild")
    @commands.is_owner()
    async def sync_guild(self, ctx):
        """Sync slash commands for this guild only (faster)."""
        self.bot.tree.copy_global_to(guild=ctx.guild)
        await self.bot.tree.sync(guild=ctx.guild)
        await ctx.send(embed=success_embed("Slash commands sincronizados neste servidor."))


async def setup(bot):
    await bot.add_cog(Admin(bot))
