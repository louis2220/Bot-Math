import datetime

import discord
from discord.ext import commands

from utils.helpers import success_embed, error_embed, mod_embed, parse_duration, format_duration
from utils.config import Config


class Moderation(commands.Cog):
    """Moderation commands."""

    def __init__(self, bot):
        self.bot = bot

    async def log_action(self, guild: discord.Guild, embed: discord.Embed):
        if Config.MOD_LOG_CHANNEL:
            ch = guild.get_channel(Config.MOD_LOG_CHANNEL)
            if ch:
                await ch.send(embed=embed)

    # ── Ban ───────────────────────────────────────────────────────────────

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def ban(self, ctx, target: discord.Member, *, reason: str = None):
        """Ban a member."""
        if target.top_role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("Você não pode banir alguém com cargo igual ou maior."))

        await target.ban(reason=reason, delete_message_days=1)

        # Save ticket
        await self.bot.db.execute(
            "INSERT INTO tickets (guild_id, user_id, mod_id, action, reason) VALUES ($1,$2,$3,$4,$5)",
            ctx.guild.id, target.id, ctx.author.id, "ban", reason
        )

        embed = mod_embed("ban", target, ctx.author, reason)
        await ctx.send(embed=embed)
        await self.log_action(ctx.guild, embed)

    @commands.command()
    @commands.has_permissions(ban_members=True)
    async def unban(self, ctx, user_id: int, *, reason: str = None):
        """Unban a user by ID."""
        try:
            user = await self.bot.fetch_user(user_id)
            await ctx.guild.unban(user, reason=reason)
            await ctx.send(embed=success_embed(f"{user.mention} foi desbanido."))
        except discord.NotFound:
            await ctx.send(embed=error_embed("Usuário não encontrado ou não está banido."))

    # ── Kick ──────────────────────────────────────────────────────────────

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def kick(self, ctx, target: discord.Member, *, reason: str = None):
        """Kick a member."""
        if target.top_role >= ctx.author.top_role:
            return await ctx.send(embed=error_embed("Você não pode expulsar alguém com cargo igual ou maior."))

        await target.kick(reason=reason)

        await self.bot.db.execute(
            "INSERT INTO tickets (guild_id, user_id, mod_id, action, reason) VALUES ($1,$2,$3,$4,$5)",
            ctx.guild.id, target.id, ctx.author.id, "kick", reason
        )

        embed = mod_embed("kick", target, ctx.author, reason)
        await ctx.send(embed=embed)
        await self.log_action(ctx.guild, embed)

    # ── Mute (Timeout) ────────────────────────────────────────────────────

    @commands.command()
    @commands.has_permissions(moderate_members=True)
    async def mute(self, ctx, target: discord.Member, duration: str = "10m", *, reason: str = None):
        """Timeout a member. Duration e.g: 10m, 1h, 7d."""
        td = parse_duration(duration)
        if not td:
            return await ctx.send(embed=error_embed("Duração inválida. Ex: `10m`, `1h`, `7d`"))

        until = discord.utils.utcnow() + td
        await target.timeout(until, reason=reason)

        await self.bot.db.execute(
            "INSERT INTO tickets (guild_id, user_id, mod_id, action, reason, duration, expires_at) VALUES ($1,$2,$3,$4,$5,$6,$7)",
            ctx.guild.id, target.id, ctx.author.id, "mute", reason, td, until
        )

        embed = mod_embed("mute", target, ctx.author, reason, format_duration(td))
        await ctx.send(embed=embed)
        await self.log_action(ctx.guild, embed)

    @commands.command()
    @commands.has_permissions(moderate_members=True)
    async def unmute(self, ctx, target: discord.Member, *, reason: str = None):
        """Remove timeout from a member."""
        await target.timeout(None, reason=reason)
        embed = mod_embed("unmute", target, ctx.author, reason)
        await ctx.send(embed=embed)
        await self.log_action(ctx.guild, embed)

    # ── Warn ──────────────────────────────────────────────────────────────

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def warn(self, ctx, target: discord.Member, *, reason: str):
        """Warn a member and DM them."""
        await self.bot.db.execute(
            "INSERT INTO tickets (guild_id, user_id, mod_id, action, reason) VALUES ($1,$2,$3,$4,$5)",
            ctx.guild.id, target.id, ctx.author.id, "warn", reason
        )

        try:
            await target.send(embed=discord.Embed(
                title=f"⚠️ Aviso em {ctx.guild.name}",
                description=f"**Motivo:** {reason}",
                color=0xF1C40F
            ))
        except discord.Forbidden:
            pass

        embed = mod_embed("warn", target, ctx.author, reason)
        await ctx.send(embed=embed)
        await self.log_action(ctx.guild, embed)

    # ── Infractions ───────────────────────────────────────────────────────

    @commands.command(aliases=["inf", "infractions"])
    @commands.has_permissions(kick_members=True)
    async def history(self, ctx, target: discord.Member):
        """Show infraction history for a member."""
        rows = await self.bot.db.fetch(
            "SELECT * FROM tickets WHERE guild_id=$1 AND user_id=$2 AND hidden=FALSE ORDER BY created_at DESC",
            ctx.guild.id, target.id
        )
        if not rows:
            return await ctx.send(embed=discord.Embed(description=f"{target.mention} não possui infrações.", color=0x2ECC71))

        embed = discord.Embed(title=f"Histórico de {target.display_name}", color=0xE74C3C)
        for r in rows[:10]:
            mod = ctx.guild.get_member(r["mod_id"])
            mod_str = mod.mention if mod else f"`{r['mod_id']}`"
            val = f"**Mod:** {mod_str}\n**Motivo:** {r['reason'] or 'N/A'}"
            if r["duration"]:
                val += f"\n**Duração:** {r['duration']}"
            embed.add_field(
                name=f"#{r['id']} — {r['action'].upper()} — {r['created_at'].strftime('%d/%m/%Y')}",
                value=val,
                inline=False
            )
        embed.set_footer(text=f"{len(rows)} infrações no total")
        await ctx.send(embed=embed)

    # ── Purge ─────────────────────────────────────────────────────────────

    @commands.command(aliases=["clear"])
    @commands.has_permissions(manage_messages=True)
    async def purge(self, ctx, amount: int):
        """Delete messages in bulk."""
        if amount < 1 or amount > 200:
            return await ctx.send(embed=error_embed("Quantidade deve ser entre 1 e 200."))
        deleted = await ctx.channel.purge(limit=amount + 1)
        msg = await ctx.send(embed=success_embed(f"{len(deleted)-1} mensagens deletadas."))
        await msg.delete(delay=3)

    # ── Note ──────────────────────────────────────────────────────────────

    @commands.command()
    @commands.has_permissions(kick_members=True)
    async def note(self, ctx, target: discord.Member, *, content: str):
        """Add a staff note to a member (not visible to them)."""
        await self.bot.db.execute(
            "INSERT INTO tickets (guild_id, user_id, mod_id, action, reason, approved) VALUES ($1,$2,$3,'note',$4,TRUE)",
            ctx.guild.id, target.id, ctx.author.id, content
        )
        await ctx.send(embed=success_embed(f"Nota adicionada para {target.mention}."))


async def setup(bot):
    await bot.add_cog(Moderation(bot))
