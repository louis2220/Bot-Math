import re
import discord
from discord.ext import commands

from utils.helpers import success_embed, error_embed, info_embed


KNOWN_PHISHING_PATTERNS = [
    r"discord[.-]gift",
    r"steamcommunity\.ru",
    r"free-nitro",
    r"nitro-gift",
    r"claimnitro",
]


class AutoMod(commands.Cog):
    """Automatic moderation — keyword scanning and anti-phishing."""

    def __init__(self, bot):
        self.bot = bot
        self.phishing_re = re.compile("|".join(KNOWN_PHISHING_PATTERNS), re.IGNORECASE)

    async def get_patterns(self, guild_id: int):
        return await self.bot.db.fetch(
            "SELECT * FROM automod_patterns WHERE guild_id=$1", guild_id
        )

    def matches_pattern(self, row, content: str) -> bool:
        pt = row["pattern_type"]
        p = row["pattern"]
        content_lower = content.lower()
        if pt == "substring":
            return p.lower() in content_lower
        elif pt == "word":
            return bool(re.search(rf"\b{re.escape(p)}\b", content, re.IGNORECASE))
        elif pt == "regex":
            return bool(re.search(p, content, re.IGNORECASE))
        return False

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        if message.author.guild_permissions.manage_messages:
            return  # Exempt mods

        content = message.content

        # Anti-phishing check
        if self.phishing_re.search(content):
            await message.delete()
            try:
                await message.guild.ban(message.author, reason="Anti-phishing automod", delete_message_days=1)
            except discord.Forbidden:
                pass
            await message.channel.send(
                f"🚫 {message.author.mention} foi banido automaticamente por enviar link de phishing.",
                delete_after=10
            )
            return

        # Custom patterns
        patterns = await self.get_patterns(message.guild.id)
        for row in patterns:
            if self.matches_pattern(row, content):
                action = row["action"]
                await message.delete()

                if action == "mute":
                    try:
                        import datetime
                        until = discord.utils.utcnow() + datetime.timedelta(minutes=10)
                        await message.author.timeout(until, reason=f"AutoMod: padrão #{row['id']}")
                    except discord.Forbidden:
                        pass
                elif action == "kick":
                    try:
                        await message.author.kick(reason=f"AutoMod: padrão #{row['id']}")
                    except discord.Forbidden:
                        pass
                elif action == "ban":
                    try:
                        await message.guild.ban(message.author, reason=f"AutoMod: padrão #{row['id']}")
                    except discord.Forbidden:
                        pass

                await message.channel.send(
                    f"🤖 Mensagem de {message.author.mention} removida por AutoMod.",
                    delete_after=5
                )
                break

    # ── Commands ───────────────────────────────────────────────────────────

    @commands.group(name="automod", invoke_without_command=True)
    @commands.has_permissions(manage_guild=True)
    async def automod_cmd(self, ctx):
        await ctx.send_help(ctx.command)

    @automod_cmd.command(name="list")
    @commands.has_permissions(manage_guild=True)
    async def automod_list(self, ctx):
        rows = await self.get_patterns(ctx.guild.id)
        if not rows:
            return await ctx.send(embed=info_embed("Nenhum padrão configurado.", "AutoMod"))
        lines = [f"`#{r['id']}` [{r['pattern_type']}] `{r['pattern']}` → **{r['action']}**" for r in rows]
        await ctx.send(embed=discord.Embed(
            title="Padrões AutoMod",
            description="\n".join(lines),
            color=0xE74C3C
        ))

    @automod_cmd.command(name="add")
    @commands.has_permissions(manage_guild=True)
    async def automod_add(self, ctx, pattern_type: str, action: str, *, pattern: str):
        """Add a pattern. Types: substring, word, regex. Actions: delete, mute, kick, ban."""
        if pattern_type not in ("substring", "word", "regex"):
            return await ctx.send(embed=error_embed("Tipo inválido. Use: substring, word, regex"))
        if action not in ("delete", "mute", "kick", "ban", "note"):
            return await ctx.send(embed=error_embed("Ação inválida. Use: delete, mute, kick, ban, note"))

        await self.bot.db.execute(
            "INSERT INTO automod_patterns (guild_id, pattern_type, pattern, action) VALUES ($1,$2,$3,$4)",
            ctx.guild.id, pattern_type, pattern, action
        )
        await ctx.send(embed=success_embed(f"Padrão adicionado: [{pattern_type}] `{pattern}` → **{action}**"))

    @automod_cmd.command(name="remove")
    @commands.has_permissions(manage_guild=True)
    async def automod_remove(self, ctx, pattern_id: int):
        """Remove a pattern by ID."""
        result = await self.bot.db.execute(
            "DELETE FROM automod_patterns WHERE id=$1 AND guild_id=$2",
            pattern_id, ctx.guild.id
        )
        if result == "DELETE 0":
            await ctx.send(embed=error_embed(f"Padrão #{pattern_id} não encontrado."))
        else:
            await ctx.send(embed=success_embed(f"Padrão #{pattern_id} removido."))


async def setup(bot):
    await bot.add_cog(AutoMod(bot))
