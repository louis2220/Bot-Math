import discord
from discord.ext import commands
from utils.config import Config


class Logs(commands.Cog):
    """Message and member event logging."""

    def __init__(self, bot):
        self.bot = bot

    async def get_log_channel(self, guild: discord.Guild):
        if Config.MOD_LOG_CHANNEL:
            return guild.get_channel(Config.MOD_LOG_CHANNEL)
        return None

    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if message.author.bot or not message.guild:
            return
        ch = await self.get_log_channel(message.guild)
        if not ch:
            return
        e = discord.Embed(
            title="🗑️ Mensagem Deletada",
            color=0xE74C3C
        )
        e.set_author(name=str(message.author), icon_url=message.author.display_avatar.url)
        e.add_field(name="Canal", value=message.channel.mention, inline=True)
        e.add_field(name="Autor", value=message.author.mention, inline=True)
        if message.content:
            e.add_field(name="Conteúdo", value=message.content[:1000], inline=False)
        import datetime
        e.timestamp = datetime.datetime.utcnow()
        await ch.send(embed=e)

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if before.author.bot or not before.guild:
            return
        if before.content == after.content:
            return
        ch = await self.get_log_channel(before.guild)
        if not ch:
            return
        e = discord.Embed(title="✏️ Mensagem Editada", color=0xF39C12)
        e.set_author(name=str(before.author), icon_url=before.author.display_avatar.url)
        e.add_field(name="Canal", value=before.channel.mention, inline=True)
        e.add_field(name="Antes", value=before.content[:500] or "*vazio*", inline=False)
        e.add_field(name="Depois", value=after.content[:500] or "*vazio*", inline=False)
        e.add_field(name="Link", value=f"[Ir para mensagem]({after.jump_url})", inline=False)
        import datetime
        e.timestamp = datetime.datetime.utcnow()
        await ch.send(embed=e)

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        ch = await self.get_log_channel(member.guild)
        if not ch:
            return
        import datetime
        account_age = datetime.datetime.utcnow() - member.created_at.replace(tzinfo=None)
        e = discord.Embed(
            title="📥 Membro Entrou",
            color=0x2ECC71
        )
        e.set_thumbnail(url=member.display_avatar.url)
        e.add_field(name="Usuário", value=f"{member.mention} ({member})", inline=False)
        e.add_field(name="ID", value=str(member.id), inline=True)
        e.add_field(name="Conta criada", value=f"<t:{int(member.created_at.timestamp())}:R>", inline=True)
        if account_age.days < 7:
            e.color = 0xF39C12
            e.add_field(name="⚠️ Conta nova", value=f"{account_age.days} dia(s)", inline=True)
        e.set_footer(text=f"Total de membros: {member.guild.member_count}")
        e.timestamp = datetime.datetime.utcnow()
        await ch.send(embed=e)

        # Restore roles (persistence)
        row = await self.bot.db.fetchrow(
            "SELECT role_ids FROM role_persistence WHERE guild_id=$1 AND user_id=$2",
            member.guild.id, member.id
        )
        if row and row["role_ids"]:
            roles = [member.guild.get_role(rid) for rid in row["role_ids"] if member.guild.get_role(rid)]
            if roles:
                await member.add_roles(*roles, reason="Role persistence")

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        ch = await self.get_log_channel(member.guild)

        # Save roles for persistence
        role_ids = [r.id for r in member.roles if not r.is_default()]
        await self.bot.db.execute(
            """INSERT INTO role_persistence (guild_id, user_id, role_ids)
               VALUES ($1,$2,$3)
               ON CONFLICT (guild_id, user_id) DO UPDATE SET role_ids=$3""",
            member.guild.id, member.id, role_ids
        )

        if not ch:
            return
        import datetime
        e = discord.Embed(title="📤 Membro Saiu", color=0xE74C3C)
        e.set_thumbnail(url=member.display_avatar.url)
        e.add_field(name="Usuário", value=f"{member} (`{member.id}`)", inline=False)
        roles = [r.mention for r in member.roles if not r.is_default()]
        if roles:
            e.add_field(name="Cargos", value=", ".join(roles[:10]), inline=False)
        e.set_footer(text=f"Total de membros: {member.guild.member_count}")
        e.timestamp = datetime.datetime.utcnow()
        await ch.send(embed=e)

    @commands.Cog.listener()
    async def on_member_update(self, before: discord.Member, after: discord.Member):
        if before.display_name == after.display_name:
            return
        ch = await self.get_log_channel(before.guild)
        if not ch:
            return
        import datetime
        e = discord.Embed(title="📝 Nickname Alterado", color=0x3498DB)
        e.set_author(name=str(after), icon_url=after.display_avatar.url)
        e.add_field(name="Antes", value=before.display_name, inline=True)
        e.add_field(name="Depois", value=after.display_name, inline=True)
        e.timestamp = datetime.datetime.utcnow()
        await ch.send(embed=e)


async def setup(bot):
    await bot.add_cog(Logs(bot))
