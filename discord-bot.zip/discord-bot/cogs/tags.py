import discord
from discord.ext import commands
from discord import app_commands

from utils.helpers import success_embed, error_embed, info_embed


class Tags(commands.Cog):
    """Tag/factoid system."""

    def __init__(self, bot):
        self.bot = bot

    async def get_tag(self, guild_id: int, name: str):
        # Try exact name
        row = await self.bot.db.fetchrow(
            "SELECT t.* FROM tags t WHERE t.guild_id=$1 AND t.name=$2", guild_id, name.lower()
        )
        if row:
            return row
        # Try alias
        row = await self.bot.db.fetchrow(
            """SELECT t.* FROM tags t
               JOIN tag_aliases a ON a.tag_id = t.id
               WHERE t.guild_id=$1 AND a.alias=$2""",
            guild_id, name.lower()
        )
        return row

    @commands.group(name="tag", aliases=["t"], invoke_without_command=True)
    async def tag(self, ctx, *, name: str):
        """Retrieve a tag."""
        row = await self.get_tag(ctx.guild.id, name)
        if not row:
            return await ctx.send(embed=error_embed(f"Tag `{name}` não encontrada."))

        await self.bot.db.execute("UPDATE tags SET uses = uses + 1 WHERE id=$1", row["id"])

        if row["embed"]:
            data = row["embed"]
            e = discord.Embed.from_dict(data)
            await ctx.send(embed=e)
        else:
            await ctx.send(row["content"])

    @tag.command(name="add", aliases=["create"])
    @commands.has_permissions(manage_messages=True)
    async def tag_add(self, ctx, name: str, *, content: str):
        """Add a new tag."""
        try:
            await self.bot.db.execute(
                "INSERT INTO tags (guild_id, name, content, owner_id) VALUES ($1,$2,$3,$4)",
                ctx.guild.id, name.lower(), content, ctx.author.id
            )
            await ctx.send(embed=success_embed(f"Tag `{name}` criada."))
        except Exception:
            await ctx.send(embed=error_embed(f"Tag `{name}` já existe."))

    @tag.command(name="edit")
    @commands.has_permissions(manage_messages=True)
    async def tag_edit(self, ctx, name: str, *, content: str):
        """Edit an existing tag."""
        result = await self.bot.db.execute(
            "UPDATE tags SET content=$1 WHERE guild_id=$2 AND name=$3",
            content, ctx.guild.id, name.lower()
        )
        if result == "UPDATE 0":
            await ctx.send(embed=error_embed(f"Tag `{name}` não encontrada."))
        else:
            await ctx.send(embed=success_embed(f"Tag `{name}` atualizada."))

    @tag.command(name="delete", aliases=["remove"])
    @commands.has_permissions(manage_messages=True)
    async def tag_delete(self, ctx, *, name: str):
        """Delete a tag."""
        result = await self.bot.db.execute(
            "DELETE FROM tags WHERE guild_id=$1 AND name=$2",
            ctx.guild.id, name.lower()
        )
        if result == "DELETE 0":
            await ctx.send(embed=error_embed(f"Tag `{name}` não encontrada."))
        else:
            await ctx.send(embed=success_embed(f"Tag `{name}` deletada."))

    @tag.command(name="alias")
    @commands.has_permissions(manage_messages=True)
    async def tag_alias(self, ctx, existing: str, alias: str):
        """Add an alias to a tag."""
        row = await self.get_tag(ctx.guild.id, existing)
        if not row:
            return await ctx.send(embed=error_embed(f"Tag `{existing}` não encontrada."))
        try:
            await self.bot.db.execute(
                "INSERT INTO tag_aliases (guild_id, alias, tag_id) VALUES ($1,$2,$3)",
                ctx.guild.id, alias.lower(), row["id"]
            )
            await ctx.send(embed=success_embed(f"Alias `{alias}` adicionado para a tag `{existing}`."))
        except Exception:
            await ctx.send(embed=error_embed(f"Alias `{alias}` já existe."))

    @tag.command(name="info")
    async def tag_info(self, ctx, *, name: str):
        """Show info about a tag."""
        row = await self.get_tag(ctx.guild.id, name)
        if not row:
            return await ctx.send(embed=error_embed(f"Tag `{name}` não encontrada."))

        aliases = await self.bot.db.fetch(
            "SELECT alias FROM tag_aliases WHERE tag_id=$1", row["id"]
        )
        owner = ctx.guild.get_member(row["owner_id"])

        e = discord.Embed(title=f"Tag: {row['name']}", color=0x7289DA)
        e.add_field(name="Dono", value=str(owner) if owner else "Desconhecido", inline=True)
        e.add_field(name="Usos", value=str(row["uses"]), inline=True)
        e.add_field(name="Criado em", value=row["created_at"].strftime("%d/%m/%Y"), inline=True)
        if aliases:
            e.add_field(name="Aliases", value=", ".join(f"`{a['alias']}`" for a in aliases), inline=False)
        await ctx.send(embed=e)

    @tag.command(name="list")
    async def tag_list(self, ctx):
        """List all tags in this server."""
        rows = await self.bot.db.fetch(
            "SELECT name, uses FROM tags WHERE guild_id=$1 ORDER BY uses DESC",
            ctx.guild.id
        )
        if not rows:
            return await ctx.send(embed=info_embed("Nenhuma tag cadastrada.", "Tags"))

        lines = [f"`{r['name']}` — {r['uses']} uso(s)" for r in rows[:30]]
        await ctx.send(embed=discord.Embed(
            title=f"Tags ({len(rows)})",
            description="\n".join(lines),
            color=0x7289DA
        ))

    @tag.command(name="top")
    async def tag_top(self, ctx):
        """Show most used tags."""
        rows = await self.bot.db.fetch(
            "SELECT name, uses FROM tags WHERE guild_id=$1 ORDER BY uses DESC LIMIT 10",
            ctx.guild.id
        )
        if not rows:
            return await ctx.send(embed=info_embed("Nenhuma tag cadastrada.", "Top Tags"))

        lines = [f"**{i+1}.** `{r['name']}` — {r['uses']} usos" for i, r in enumerate(rows)]
        await ctx.send(embed=discord.Embed(
            title="🏆 Top Tags",
            description="\n".join(lines),
            color=0xF1C40F
        ))

    # Slash command for quick tag lookup
    @app_commands.command(name="tag", description="Buscar uma tag")
    @app_commands.describe(name="Nome da tag")
    async def slash_tag(self, interaction: discord.Interaction, name: str):
        row = await self.get_tag(interaction.guild_id, name)
        if not row:
            return await interaction.response.send_message(f"Tag `{name}` não encontrada.", ephemeral=True)
        await self.bot.db.execute("UPDATE tags SET uses = uses + 1 WHERE id=$1", row["id"])
        await interaction.response.send_message(row["content"])


async def setup(bot):
    await bot.add_cog(Tags(bot))
