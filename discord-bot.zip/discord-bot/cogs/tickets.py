import discord
from discord.ext import commands

from utils.helpers import success_embed, error_embed, info_embed


class Tickets(commands.Cog):
    """Ticket management."""

    def __init__(self, bot):
        self.bot = bot

    @commands.group(name="ticket", invoke_without_command=True)
    @commands.has_permissions(kick_members=True)
    async def ticket(self, ctx):
        await ctx.send_help(ctx.command)

    @ticket.command(name="show")
    @commands.has_permissions(kick_members=True)
    async def ticket_show(self, ctx, ticket_id: int):
        """Show a specific ticket."""
        row = await self.bot.db.fetchrow(
            "SELECT * FROM tickets WHERE id=$1 AND guild_id=$2",
            ticket_id, ctx.guild.id
        )
        if not row:
            return await ctx.send(embed=error_embed(f"Ticket #{ticket_id} não encontrado."))

        user = ctx.guild.get_member(row["user_id"]) or await self.bot.fetch_user(row["user_id"])
        mod = ctx.guild.get_member(row["mod_id"]) if row["mod_id"] else None

        e = discord.Embed(title=f"Ticket #{row['id']}", color=0x7289DA)
        e.add_field(name="Usuário", value=f"{user} (`{user.id}`)", inline=True)
        e.add_field(name="Ação", value=row["action"].upper(), inline=True)
        e.add_field(name="Moderador", value=str(mod) if mod else "N/A", inline=True)
        e.add_field(name="Motivo", value=row["reason"] or "N/A", inline=False)
        if row["duration"]:
            e.add_field(name="Duração", value=str(row["duration"]), inline=True)
        e.add_field(name="Data", value=row["created_at"].strftime("%d/%m/%Y %H:%M"), inline=True)
        status = []
        if not row["approved"]:
            status.append("⚠️ Não aprovado")
        if row["hidden"]:
            status.append("👁️ Oculto")
        if status:
            e.add_field(name="Status", value=", ".join(status), inline=False)
        await ctx.send(embed=e)

    @ticket.command(name="hide")
    @commands.has_permissions(ban_members=True)
    async def ticket_hide(self, ctx, ticket_id: int):
        """Hide a ticket."""
        await self.bot.db.execute(
            "UPDATE tickets SET hidden=TRUE WHERE id=$1 AND guild_id=$2",
            ticket_id, ctx.guild.id
        )
        await ctx.send(embed=success_embed(f"Ticket #{ticket_id} ocultado."))

    @ticket.command(name="approve")
    @commands.has_permissions(ban_members=True)
    async def ticket_approve(self, ctx, ticket_id: int):
        """Approve a ticket."""
        await self.bot.db.execute(
            "UPDATE tickets SET approved=TRUE WHERE id=$1 AND guild_id=$2",
            ticket_id, ctx.guild.id
        )
        await ctx.send(embed=success_embed(f"Ticket #{ticket_id} aprovado."))

    @ticket.command(name="reason")
    @commands.has_permissions(kick_members=True)
    async def ticket_reason(self, ctx, ticket_id: int, *, reason: str):
        """Update the reason for a ticket."""
        await self.bot.db.execute(
            "UPDATE tickets SET reason=$1 WHERE id=$2 AND guild_id=$3",
            reason, ticket_id, ctx.guild.id
        )
        await ctx.send(embed=success_embed(f"Ticket #{ticket_id} atualizado."))

    @commands.command(name="tickets")
    @commands.has_permissions(kick_members=True)
    async def tickets_list(self, ctx, target: discord.Member):
        """List tickets for a user."""
        rows = await self.bot.db.fetch(
            "SELECT id, action, created_at, approved FROM tickets WHERE guild_id=$1 AND user_id=$2 AND hidden=FALSE ORDER BY created_at DESC",
            ctx.guild.id, target.id
        )
        if not rows:
            return await ctx.send(embed=info_embed(f"{target.mention} não tem tickets.", "Tickets"))

        lines = [f"`#{r['id']}` **{r['action'].upper()}** — {r['created_at'].strftime('%d/%m/%Y')}" + (" ⚠️" if not r["approved"] else "") for r in rows]
        embed = discord.Embed(
            title=f"Tickets de {target.display_name}",
            description="\n".join(lines),
            color=0x7289DA
        )
        await ctx.send(embed=embed)


async def setup(bot):
    await bot.add_cog(Tickets(bot))
