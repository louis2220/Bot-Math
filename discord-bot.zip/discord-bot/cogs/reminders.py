import datetime
import asyncio
import discord
from discord.ext import commands, tasks
from discord import app_commands

from utils.helpers import success_embed, error_embed, parse_duration, format_duration


class Reminders(commands.Cog):
    """Set and manage reminders."""

    def __init__(self, bot):
        self.bot = bot
        self.check_reminders.start()

    def cog_unload(self):
        self.check_reminders.cancel()

    @commands.command(name="remindme", aliases=["remind"])
    async def remindme(self, ctx, duration: str, *, content: str):
        """Set a reminder. Example: .remindme 2h Study for exam"""
        td = parse_duration(duration)
        if not td:
            return await ctx.send(embed=error_embed("Duração inválida. Ex: `10m`, `2h`, `1d`"))

        remind_at = datetime.datetime.utcnow() + td
        await self.bot.db.execute(
            "INSERT INTO reminders (user_id, channel_id, content, remind_at) VALUES ($1,$2,$3,$4)",
            ctx.author.id, ctx.channel.id, content, remind_at
        )
        await ctx.send(embed=success_embed(
            f"Lembrete criado! Vou te avisar em **{format_duration(td)}**.\n> {content}"
        ))

    @app_commands.command(name="remindme", description="Criar um lembrete")
    @app_commands.describe(duration="Duração (ex: 10m, 2h, 1d)", content="O que lembrar")
    async def slash_remindme(self, interaction: discord.Interaction, duration: str, content: str):
        td = parse_duration(duration)
        if not td:
            return await interaction.response.send_message("Duração inválida.", ephemeral=True)
        remind_at = datetime.datetime.utcnow() + td
        await self.bot.db.execute(
            "INSERT INTO reminders (user_id, channel_id, content, remind_at) VALUES ($1,$2,$3,$4)",
            interaction.user.id, interaction.channel_id, content, remind_at
        )
        await interaction.response.send_message(
            embed=success_embed(f"Lembrete em **{format_duration(td)}**: {content}"),
            ephemeral=True
        )

    @commands.group(name="reminders", invoke_without_command=True)
    async def reminders_list(self, ctx):
        """List your active reminders."""
        rows = await self.bot.db.fetch(
            "SELECT id, content, remind_at FROM reminders WHERE user_id=$1 ORDER BY remind_at",
            ctx.author.id
        )
        if not rows:
            return await ctx.send(embed=discord.Embed(description="Você não tem lembretes ativos.", color=0x95A5A6))

        lines = [
            f"`#{r['id']}` — <t:{int(r['remind_at'].timestamp())}:R>\n> {r['content']}"
            for r in rows
        ]
        await ctx.send(embed=discord.Embed(
            title="Seus Lembretes",
            description="\n\n".join(lines),
            color=0x7289DA
        ))

    @reminders_list.command(name="remove", aliases=["delete"])
    async def reminder_remove(self, ctx, reminder_id: int):
        """Remove a reminder by ID."""
        result = await self.bot.db.execute(
            "DELETE FROM reminders WHERE id=$1 AND user_id=$2",
            reminder_id, ctx.author.id
        )
        if result == "DELETE 0":
            await ctx.send(embed=error_embed("Lembrete não encontrado ou não pertence a você."))
        else:
            await ctx.send(embed=success_embed(f"Lembrete `#{reminder_id}` removido."))

    @tasks.loop(seconds=30)
    async def check_reminders(self):
        now = datetime.datetime.utcnow()
        rows = await self.bot.db.fetch(
            "DELETE FROM reminders WHERE remind_at <= $1 RETURNING *", now
        )
        for row in rows:
            channel = self.bot.get_channel(row["channel_id"])
            if not channel:
                continue
            try:
                await channel.send(
                    f"⏰ <@{row['user_id']}> Lembrete!\n> {row['content']}"
                )
            except discord.Forbidden:
                pass

    @check_reminders.before_loop
    async def before_check(self):
        await self.bot.wait_until_ready()


async def setup(bot):
    await bot.add_cog(Reminders(bot))
