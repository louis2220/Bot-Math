import logging
import asyncpg
from utils.config import Config

log = logging.getLogger("db")


class Database:
    def __init__(self):
        self.pool: asyncpg.Pool = None

    async def connect(self):
        self.pool = await asyncpg.create_pool(Config.DATABASE_URL, min_size=2, max_size=10)
        log.info("Connected to PostgreSQL.")

    async def close(self):
        await self.pool.close()

    async def execute(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.execute(query, *args)

    async def fetchrow(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetchrow(query, *args)

    async def fetch(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetch(query, *args)

    async def fetchval(self, query: str, *args):
        async with self.pool.acquire() as conn:
            return await conn.fetchval(query, *args)

    async def init_tables(self):
        async with self.pool.acquire() as conn:
            await conn.execute("""
                -- Tickets / Infractions
                CREATE TABLE IF NOT EXISTS tickets (
                    id SERIAL PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    mod_id BIGINT,
                    action TEXT NOT NULL,
                    reason TEXT,
                    duration INTERVAL,
                    expires_at TIMESTAMPTZ,
                    approved BOOLEAN DEFAULT TRUE,
                    hidden BOOLEAN DEFAULT FALSE,
                    created_at TIMESTAMPTZ DEFAULT NOW()
                );

                -- Tags / Factoids
                CREATE TABLE IF NOT EXISTS tags (
                    id SERIAL PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    name TEXT NOT NULL,
                    content TEXT NOT NULL,
                    embed JSONB,
                    owner_id BIGINT,
                    uses INT DEFAULT 0,
                    created_at TIMESTAMPTZ DEFAULT NOW(),
                    UNIQUE(guild_id, name)
                );

                CREATE TABLE IF NOT EXISTS tag_aliases (
                    id SERIAL PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    alias TEXT NOT NULL,
                    tag_id INT REFERENCES tags(id) ON DELETE CASCADE,
                    UNIQUE(guild_id, alias)
                );

                -- Roles / Self-assign
                CREATE TABLE IF NOT EXISTS selfroles (
                    id SERIAL PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    role_id BIGINT NOT NULL,
                    label TEXT,
                    description TEXT,
                    UNIQUE(guild_id, role_id)
                );

                -- Role reactions
                CREATE TABLE IF NOT EXISTS role_reactions (
                    id SERIAL PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    message_id BIGINT NOT NULL,
                    emoji TEXT NOT NULL,
                    role_id BIGINT NOT NULL,
                    UNIQUE(message_id, emoji)
                );

                -- Clopen channels
                CREATE TABLE IF NOT EXISTS clopen_channels (
                    id SERIAL PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL UNIQUE,
                    status TEXT DEFAULT 'available',
                    owner_id BIGINT,
                    opened_at TIMESTAMPTZ,
                    last_message_at TIMESTAMPTZ,
                    timeout_multiplier INT DEFAULT 1
                );

                -- Modmail threads
                CREATE TABLE IF NOT EXISTS modmail_threads (
                    id SERIAL PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    thread_channel_id BIGINT,
                    open BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMPTZ DEFAULT NOW(),
                    last_message_at TIMESTAMPTZ DEFAULT NOW()
                );

                -- Automod patterns
                CREATE TABLE IF NOT EXISTS automod_patterns (
                    id SERIAL PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    pattern_type TEXT NOT NULL,
                    pattern TEXT NOT NULL,
                    action TEXT DEFAULT 'delete',
                    created_at TIMESTAMPTZ DEFAULT NOW()
                );

                -- Reminders
                CREATE TABLE IF NOT EXISTS reminders (
                    id SERIAL PRIMARY KEY,
                    user_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    content TEXT NOT NULL,
                    remind_at TIMESTAMPTZ NOT NULL,
                    created_at TIMESTAMPTZ DEFAULT NOW()
                );

                -- Member role persistence
                CREATE TABLE IF NOT EXISTS role_persistence (
                    guild_id BIGINT NOT NULL,
                    user_id BIGINT NOT NULL,
                    role_ids BIGINT[] DEFAULT '{}',
                    PRIMARY KEY(guild_id, user_id)
                );

                -- Polls
                CREATE TABLE IF NOT EXISTS polls (
                    id SERIAL PRIMARY KEY,
                    guild_id BIGINT NOT NULL,
                    channel_id BIGINT NOT NULL,
                    message_id BIGINT,
                    author_id BIGINT NOT NULL,
                    question TEXT NOT NULL,
                    expires_at TIMESTAMPTZ NOT NULL,
                    open BOOLEAN DEFAULT TRUE,
                    created_at TIMESTAMPTZ DEFAULT NOW()
                );

                CREATE TABLE IF NOT EXISTS poll_votes (
                    poll_id INT REFERENCES polls(id) ON DELETE CASCADE,
                    user_id BIGINT NOT NULL,
                    vote TEXT NOT NULL,
                    PRIMARY KEY(poll_id, user_id)
                );

                -- Config key-value store
                CREATE TABLE IF NOT EXISTS guild_config (
                    guild_id BIGINT NOT NULL,
                    namespace TEXT NOT NULL,
                    key TEXT NOT NULL,
                    value JSONB,
                    PRIMARY KEY(guild_id, namespace, key)
                );
            """)
        log.info("Database tables initialized.")
