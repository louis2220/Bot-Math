import re
from datetime import timedelta
from typing import Optional

import discord


# ── Duration parsing ──────────────────────────────────────────────────────────

DURATION_RE = re.compile(
    r"(?:(\d+)\s*(?:y(?:r|ear)?s?))?"
    r"(?:(\d+)\s*(?:mo(?:nth)?s?))?"
    r"(?:(\d+)\s*(?:w(?:k|eek)?s?))?"
    r"(?:(\d+)\s*(?:d(?:ay)?s?))?"
    r"(?:(\d+)\s*(?:h(?:r|our)?s?))?"
    r"(?:(\d+)\s*(?:m(?:in(?:ute)?)?s?))?"
    r"(?:(\d+)\s*(?:s(?:ec(?:ond)?)?s?))?",
    re.IGNORECASE,
)


def parse_duration(text: str) -> Optional[timedelta]:
    m = DURATION_RE.match(text.strip())
    if not m or not any(m.groups()):
        return None
    years, months, weeks, days, hours, minutes, seconds = (
        int(v) if v else 0 for v in m.groups()
    )
    total_days = years * 365 + months * 30 + weeks * 7 + days
    return timedelta(days=total_days, hours=hours, minutes=minutes, seconds=seconds)


def format_duration(td: timedelta) -> str:
    total = int(td.total_seconds())
    days, rem = divmod(total, 86400)
    hours, rem = divmod(rem, 3600)
    minutes, seconds = divmod(rem, 60)
    parts = []
    if days:
        parts.append(f"{days}d")
    if hours:
        parts.append(f"{hours}h")
    if minutes:
        parts.append(f"{minutes}m")
    if seconds:
        parts.append(f"{seconds}s")
    return " ".join(parts) if parts else "0s"


# ── Embeds ─────────────────────────────────────────────────────────────────────

def success_embed(description: str, title: str = None) -> discord.Embed:
    e = discord.Embed(description=f"✅ {description}", color=0x2ECC71)
    if title:
        e.title = title
    return e


def error_embed(description: str, title: str = None) -> discord.Embed:
    e = discord.Embed(description=f"❌ {description}", color=0xE74C3C)
    if title:
        e.title = title
    return e


def info_embed(description: str, title: str = None) -> discord.Embed:
    e = discord.Embed(description=description, color=0x3498DB)
    if title:
        e.title = title
    return e


def mod_embed(action: str, target: discord.Member, mod: discord.Member, reason: str, duration: str = None) -> discord.Embed:
    colors = {
        "ban": 0xE74C3C,
        "kick": 0xE67E22,
        "mute": 0xF39C12,
        "warn": 0xF1C40F,
        "unban": 0x2ECC71,
        "unmute": 0x2ECC71,
        "note": 0x95A5A6,
    }
    color = colors.get(action.lower(), 0x7289DA)
    e = discord.Embed(title=f"🔨 {action.capitalize()}", color=color)
    e.add_field(name="Usuário", value=f"{target.mention} (`{target.id}`)", inline=True)
    e.add_field(name="Moderador", value=mod.mention, inline=True)
    if duration:
        e.add_field(name="Duração", value=duration, inline=True)
    e.add_field(name="Motivo", value=reason or "Não informado", inline=False)
    e.set_thumbnail(url=target.display_avatar.url)
    import datetime
    e.timestamp = datetime.datetime.utcnow()
    return e
