import os


class Config:
    TOKEN: str = os.environ["DISCORD_TOKEN"]
    DATABASE_URL: str = os.environ["DATABASE_URL"]
    PREFIX: str = os.environ.get("BOT_PREFIX", ".")
    MOD_LOG_CHANNEL: int = int(os.environ.get("MOD_LOG_CHANNEL", 0))
    MODMAIL_CHANNEL: int = int(os.environ.get("MODMAIL_CHANNEL", 0))
    TICKET_LIST_CHANNEL: int = int(os.environ.get("TICKET_LIST_CHANNEL", 0))
